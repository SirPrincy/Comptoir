import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Field, inputStyle } from '../../ui';
import { calculerPRU } from '../logistiqueUtils';

interface Step4Props {
  commande: any;
  product: any;
  today: string;
  puAchat: number;
  setField: (key: string, value: any) => void;
  isLocked?: boolean;
}

export default function Step4Arrivee({ commande, product: p, today, puAchat, setField, isLocked }: Step4Props) {
  const fretTotal = Number(commande.fraisTransport) || 0;
  const transportLocalTotal = Number(commande.fraisTransportLocal) || 0;
  const { pruTotal } = calculerPRU({
    puAchat,
    fraisTransport: fretTotal,
    fraisTransportLocal: transportLocalTotal,
    qty: commande.qty,
  });

  return (
    <fieldset disabled={isLocked} style={{ border: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ fontSize: 13.5, fontWeight: 700, color: '#3D5A6C' }}>
        🛬 Arrivée à Madagascar & Validation Globale des Données
      </div>
      <div style={{ fontSize: 12, color: '#8A8375' }}>
        Le colis est arrivé et dédouané. Renseignez les frais de transport du transitaire vers votre entrepôt et vérifiez le prix de revient avant le Contrôle Qualité.
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field label="Date effective d'arrivée / Dédouanement">
          <input
            type="date" max={today}
            value={commande.dateArrivee ? commande.dateArrivee.slice(0, 10) : today}
            onChange={e => setField('dateArrivee', new Date(e.target.value).toISOString())}
            style={inputStyle as any}
          />
        </Field>

        <Field label="Frais transport transitaire ➔ entrepôt (Ar)">
          <input
            type="number"
            min={0}
            value={commande.fraisTransportLocal ?? ''}
            onChange={e => {
              const val = e.target.value;
              setField('fraisTransportLocal', val === '' ? '' : Math.max(0, Number(val)));
            }}
            placeholder="0 Ar (camionnage, coursier...)"
            style={inputStyle as any}
          />
        </Field>
      </div>

      <div style={{ border: '1px solid #EAE2D4', borderRadius: 8, overflow: 'hidden' }}>
        <div style={{ background: '#FAF7F2', padding: '8px 12px', fontWeight: 700, fontSize: 12, color: '#3D5A6C', borderBottom: '1px solid #EAE2D4' }}>
          Bilan Récapitulatif du Colis & Prix de Revient (PRU)
        </div>
        <div className="p-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div><span style={{ color: '#8A8375' }}>Produit :</span><br /><strong>{p?.nom} ({commande.qty} pcs)</strong></div>
          <div><span style={{ color: '#8A8375' }}>Coût Achat :</span><br /><strong>{(puAchat * Number(commande.qty || 1)).toLocaleString('fr-FR')} Ar</strong></div>
          <div><span style={{ color: '#8A8375' }}>Fret Transitaire :</span><br /><strong>{fretTotal.toLocaleString('fr-FR')} Ar</strong></div>
          <div><span style={{ color: '#8A8375' }}>Transport ➔ Entrepôt :</span><br /><strong>{transportLocalTotal.toLocaleString('fr-FR')} Ar</strong></div>
        </div>
        <div style={{ padding: '8px 12px', background: '#F4EFE6', borderTop: '1px solid #EAE2D4', fontSize: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
          <span style={{ color: '#5E584E' }}>
            Prix de Revient Unitaire réel (Achat + Fret + Transport local) :
          </span>
          <strong style={{ color: '#3F7A5C', fontSize: 13.5 }}>
            {Math.round(pruTotal).toLocaleString('fr-FR')} Ar / pièce
          </strong>
        </div>
      </div>

      <div style={{ padding: '10px 12px', background: '#E3EFE9', borderRadius: 8, border: '1px solid #C4DEC0', fontSize: 12, color: '#2C5E43', display: 'flex', alignItems: 'center', gap: 8 }}>
        <CheckCircle2 size={16} />
        <span>Toutes les informations logistiques et financières sont prêtes. Vous pouvez valider pour lancer le contrôle qualité.</span>
      </div>
    </fieldset>
  );
}
